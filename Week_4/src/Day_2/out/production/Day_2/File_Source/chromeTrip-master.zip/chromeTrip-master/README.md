![Chrome Trip](https://github.com/enthus1ast/chromeTrip/blob/master/.raw/ChromeTrip2.png?raw=true)

Chrome Trip Video: https://www.youtube.com/watch?v=TVbOfV9sPgk&t=0s

Download ready to play game binaries (linus/windows) on https://code0.itch.io/chrome-trip
